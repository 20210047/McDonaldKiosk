package panel;

import javax.swing.*;

public class CustomButton extends JButton {
    JButton button;

    public CustomButton(String text) {
        button = new JButton(text);
    }
}
