import user.UserContextHolder;
import view.AdminView;
import view.LoginView;
import view.MenuOptionView;
import view.MenuView;

public class McDonaldApplication {
    public static void main(String[] args) {

        new MenuView();
    }
}

