package view;

import panel.SouthOrderPanel;

import javax.swing.*;

public class PaymentView extends JFrame {
}