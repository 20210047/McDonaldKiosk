package db;

public class DBConfig {
    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    public static final String URL = "jdbc:mysql://127.0.0.1:3306/kkiosk";
    public static final String USER = "root";
    public static final String PW = "dnjswns2%";
}
